model_name=DLinear

for pred_len in  720 
do
seq_len=144
while [ $seq_len -le 721 ]
do
python -u run_longExp.py \
    --is_training 1 \
    --root_path ./dataset/ETT \
    --data_path ETTm1.csv \
    --model_id ETTm1_$seq_len'_'$pred_len \
    --model $model_name \
    --data ETTm1 \
    --features M \
    --seq_len $seq_len \
    --pred_len $pred_len \
    --enc_in 7 \
    --des 'Exp' \
    --stage_num 4 \
    --stage_pool_kernel 3 \
    --stage_pool_padding 0 \
    --itr 1 --batch_size 512 --learning_rate 0.01 
  let seq_len+=24
done
done